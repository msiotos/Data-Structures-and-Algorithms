package org.tuc;

public interface Element {
	
	public int getKey();

}
